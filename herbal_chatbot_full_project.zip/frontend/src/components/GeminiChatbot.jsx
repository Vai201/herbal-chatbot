import React, { useState } from 'react';

const GeminiChatbot = () => {
  const [messages, setMessages] = useState([
    { sender: 'bot', text: 'Hi! Ask me anything about herbs and medicinal plants 🌿' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = { sender: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('http://localhost:5000/api/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: input })
      });

      const data = await response.json();
      const botMessage = { sender: 'bot', text: data.reply };
      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Error fetching Gemini response:', error);
    }

    setLoading(false);
  };

  return (
    <div className="max-w-xl mx-auto mt-10 p-4">
      <div className="h-[70vh] overflow-y-auto p-4 space-y-3 bg-white rounded shadow">
        {messages.map((msg, index) => (
          <div key={index} className={`text-sm ${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>
            <span className="inline-block px-3 py-2 rounded-xl shadow bg-green-100 mb-1">
              {msg.text}
            </span>
          </div>
        ))}
      </div>
      <div className="mt-4 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about a herb..."
          className="flex-grow border border-gray-300 px-4 py-2 rounded"
        />
        <button
          onClick={handleSend}
          disabled={loading}
          className="bg-green-500 text-white px-4 py-2 rounded"
        >
          {loading ? 'Sending...' : 'Send'}
        </button>
      </div>
    </div>
  );
};

export default GeminiChatbot;
