import React from 'react';
import GeminiChatbot from './components/GeminiChatbot';

function App() {
  return (
    <div className="min-h-screen bg-green-50">
      <GeminiChatbot />
    </div>
  );
}

export default App;
